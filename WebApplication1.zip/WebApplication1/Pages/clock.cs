﻿namespace WebApplication1.Pages
{
    public class clock
    {
        internal string abbreviation;
    }
}